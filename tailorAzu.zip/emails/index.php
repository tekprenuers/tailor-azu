<?php

//This page will return a blank page on the browser but we both know that it is not empty 😃
//Placeholders used in the mail

$placeholders = array(
    "FNAME" => "User's first name",
    "EXPIRY_END_DATE" => "Date when lincense will expire",
    "UID" => "User's ID",
    "TIME" => "current time in 20 Jan 2023 format",
    "RESET_LINK" => "password reset link",
    "REFERENCE" => "Transaction Reference",
    "CUS_NAME" => "Customer's name",
    "CUS_PHONE" => "Customer's primary phone number",
    "REQUEST_NAME" => "The name fo the customer's request",
    "DEADLINE" => "Due date of the request",
    "PRONOUN" => "Him for males and Her for females"
);

die("")
?>